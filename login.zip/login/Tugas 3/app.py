from flask import Flask, render_template, request, redirect, url_for, flash
import os
from werkzeug.utils import secure_filename
from config import get_db_connection
from flask import Flask, render_template, request, redirect, url_for, flash, session




app = Flask(__name__)
app.secret_key = 'your_secret_key'

UPLOAD_FOLDER = 'static/images'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

USERNAME = 'ganteng'
PASSWORD = '1234'

lecturers = [
    {'id': 1, 'name': 'Dr. John Doe', 'description': 'Pakar dalam AI dan Pembelajaran Mesin.', 'photo': 'john_doe.jpg'},
    {'id': 2, 'name': 'Dr. Jane Smith', 'description': 'Spesialis dalam Keamanan Siber.', 'photo': 'jane_smith.jpg'}
]

students = [
    {'name': 'Alice Johnson', 'description': 'Top performer in Computer Science.', 'photo': 'alice_johnson.jpg'},
    {'name': 'Bob Brown', 'description': 'Aktif dalam penelitian dan pengembangan.', 'photo': 'bob_brown.jpg'}
]

schedules = []  # Menyimpan jadwal

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    if username == USERNAME and password == PASSWORD:
        return redirect(url_for('beranda'))
    else:
        flash('Username atau password salah. Silakan coba lagi.')
        return redirect(url_for('index'))
    
@app.route('/logout')
def logout():
    session.pop('logged_in', None)  # type: ignore # Menghapus sesi pengguna
    flash('Anda telah berhasil logout.')
    return redirect(url_for('index'))

@app.route("/beranda")
def beranda():
    return render_template('beranda.html')

@app.route('/jados')
def jados():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM lecturers')
    lecturers = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('jados.html', lecturers=lecturers)

@app.route("/jamas")
def jamas():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    schedules_by_jurusan = {}
    for jurusan, table_name in [('Teknik Informatika', 'jadwal_ti'), ('Bahasa Inggris', 'jadwal_si')]:
        cursor.execute(f'SELECT * FROM {table_name}')
        schedules_by_jurusan[jurusan] = cursor.fetchall()
    
    cursor.close()
    connection.close()
    
    return render_template('jamas.html', schedules_by_jurusan=schedules_by_jurusan)




@app.route("/jumas")
def jumas():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    cursor.execute('SELECT * FROM students')
    students = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) AS total FROM students')
    total_students = cursor.fetchone()['total']
    
    cursor.close()
    connection.close()
    
    return render_template('jumas.html', students=students, total_students=total_students)


@app.route("/lecturer/<int:id>")
def lecturer(id):
    lecturer = next((lect for lect in lecturers if lect['id'] == id), None)
    return render_template('lecturer.html', lecturer=lecturer)

@app.route("/student/<name>")
def student(name):
    student = next((stud for stud in students if stud['name'] == name), None)
    return render_template('student.html', student=student)

@app.route('/add_lecturer', methods=['GET', 'POST'])
def add_lecturer():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        photo = request.files['photo'].filename

        # Save photo
        if photo:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(photo))
            request.files['photo'].save(file_path)

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO lecturers (name, description, photo) VALUES (%s, %s, %s)', 
                       (name, description, photo))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('jados'))

    return render_template('add_lecturer.html')

@app.route('/edit_lecturer/<int:id>', methods=['GET', 'POST'])
def edit_lecturer(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        photo = request.files['photo'].filename

        if photo:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(photo))
            request.files['photo'].save(file_path)

        cursor.execute('UPDATE lecturers SET name=%s, description=%s, photo=%s WHERE id=%s',
                       (name, description, photo, id))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('jados'))

    cursor.execute('SELECT * FROM lecturers WHERE id=%s', (id,))
    lecturer = cursor.fetchone()
    cursor.close()
    conn.close()
    return render_template('edit_lecturer.html', lecturer=lecturer)

@app.route('/delete_lecturer/<int:id>', methods=['POST'])
def delete_lecturer(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM lecturers WHERE id=%s', (id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('jados'))

@app.route("/add_schedule", methods=['GET', 'POST'])
def add_schedule():
    if request.method == 'POST':
        pelajaran = request.form['pelajaran']
        waktu_mulai = request.form['waktu_mulai']
        waktu_selesai = request.form['waktu_selesai']
        hari = request.form['hari']
        jurusan = request.form['jurusan']
        
        if pelajaran and waktu_mulai and waktu_selesai and hari and jurusan:
            connection = get_db_connection()
            cursor = connection.cursor()
            
            # Pilih tabel berdasarkan jurusan
            if jurusan == 'Teknik Informatika':
                table_name = 'jadwal_ti'
            elif jurusan == 'Bahasa Inggris':
                table_name = 'jadwal_si'
            else:
                flash('Jurusan tidak dikenal.')
                return redirect(url_for('add_schedule'))
            
            cursor.execute(f'INSERT INTO {table_name} (pelajaran, waktu_mulai, waktu_selesai, hari) VALUES (%s, %s, %s, %s)', 
                           (pelajaran, waktu_mulai, waktu_selesai, hari))
            connection.commit()
            cursor.close()
            connection.close()
            return redirect(url_for('jamas'))
        else:
            flash('Semua field harus diisi.')
    return render_template('add_schedule.html')




@app.route("/edit_schedule/<int:id>", methods=['GET', 'POST'])
def edit_schedule(id):
    schedule = next((sch for sch in schedules if sch['id'] == id), None)
    if request.method == 'POST':
        schedule['course'] = request.form['course']
        schedule['time'] = request.form['time']
        return redirect(url_for('jamas'))
    return render_template('edit_schedule.html', schedule=schedule)

@app.route("/delete_schedule/<int:id>", methods=['POST'])
def delete_schedule(id):
    global schedules
    schedules = [sch for sch in schedules if sch['id'] != id]
    return redirect(url_for('jamas'))

@app.route("/add_student", methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        major = request.form['major']
        
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute('INSERT INTO students (name, description, jurusan) VALUES (%s, %s, %s)', 
                       (name, description, major))
        connection.commit()
        cursor.close()
        connection.close()
        return redirect(url_for('jumas'))
    return render_template('add_student.html')


@app.route("/edit_student/<int:id>", methods=['GET', 'POST'])
def edit_student(id):
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        major = request.form['major']
        
        cursor.execute('UPDATE students SET name = %s, description = %s, jurusan = %s WHERE id = %s',
                       (name, description, major, id))
        connection.commit()
        cursor.close()
        connection.close()
        return redirect(url_for('jumas'))
    
    cursor.execute('SELECT * FROM students WHERE id = %s', (id,))
    student = cursor.fetchone()
    cursor.close()
    connection.close()
    
    return render_template('edit_student.html', student=student)


@app.route("/delete_student/<int:id>", methods=['POST'])
def delete_student(id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('DELETE FROM students WHERE id = %s', (id,))
    connection.commit()
    cursor.close()
    connection.close()
    return redirect(url_for('jumas'))




if __name__ == '__main__':
    app.run(debug=True)
