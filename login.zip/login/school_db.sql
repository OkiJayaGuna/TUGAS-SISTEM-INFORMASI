-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2024 at 04:08 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_si`
--

CREATE TABLE `jadwal_si` (
  `id` int(11) NOT NULL,
  `pelajaran` varchar(255) DEFAULT NULL,
  `waktu_mulai` time DEFAULT NULL,
  `waktu_selesai` time DEFAULT NULL,
  `hari` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `jadwal_si`
--

INSERT INTO `jadwal_si` (`id`, `pelajaran`, `waktu_mulai`, `waktu_selesai`, `hari`) VALUES
(1, 'percakapan bahasa inggris', '08:00:00', '10:00:00', 'Senin');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_ti`
--

CREATE TABLE `jadwal_ti` (
  `id` int(11) NOT NULL,
  `pelajaran` varchar(255) DEFAULT NULL,
  `waktu_mulai` time DEFAULT NULL,
  `waktu_selesai` time DEFAULT NULL,
  `hari` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `jadwal_ti`
--

INSERT INTO `jadwal_ti` (`id`, `pelajaran`, `waktu_mulai`, `waktu_selesai`, `hari`) VALUES
(1, 'sistem informasi', '10:00:00', '12:00:00', 'Rabu');

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`id`, `name`, `description`, `photo`) VALUES
(2, 'arfan', 'dosen jurusan bahasa inggris', 'ARFAN1.jpg'),
(3, 'faisal', 'dosen jurusan teknik informatika', 'IJAL.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `pelajaran` varchar(255) NOT NULL,
  `waktu_mulai` time NOT NULL,
  `waktu_selesai` time NOT NULL,
  `hari` varchar(20) NOT NULL,
  `jurusan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `pelajaran`, `waktu_mulai`, `waktu_selesai`, `hari`, `jurusan`) VALUES
(1, 'bahasa inggris', '08:30:00', '10:00:00', 'kamis', NULL),
(2, 'bahasa indonesia', '09:00:00', '11:00:00', 'Rabu', NULL),
(3, 'bahasa inggris', '09:00:00', '10:00:00', 'Senin', NULL),
(4, 'DATA SAIN', '08:00:00', '10:00:00', 'Selasa', NULL),
(5, 'bahasa inggris', '07:00:00', '08:00:00', 'Senin', NULL),
(6, 'website', '14:00:00', '15:00:00', 'Jumat', 'teknik informatika');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `jurusan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `description`, `jurusan`) VALUES
(1, 'rizal', 'tingal dikelurahan takimpo', 'teknik informatika'),
(2, 'miranda', 'tainggal dikelurahan wakoko', 'teknik informatika'),
(3, 'anton', 'tinggal dibu bau', 'teknik informatika'),
(4, 'DYAH CHANDRA', 'TINGGAL DIJEPANG KAUPATEN BANABUNGI', 'KEDOKTERAN');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jadwal_si`
--
ALTER TABLE `jadwal_si`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jadwal_ti`
--
ALTER TABLE `jadwal_ti`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jadwal_si`
--
ALTER TABLE `jadwal_si`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jadwal_ti`
--
ALTER TABLE `jadwal_ti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lecturers`
--
ALTER TABLE `lecturers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
